CREATE SCHEMA `userdatabase` ;
use userdatabase;
grant all on userdatabase.* to 'root'@'localhost' identified by 'test';

CREATE TABLE `Employer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `companyName` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `contactNo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

CREATE TABLE `users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `skill` varchar(45) DEFAULT NULL,
  `qualification` varchar(45) DEFAULT NULL,
  `contactNo` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

CREATE TABLE `vacancy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(45) DEFAULT NULL,
  `skills_required` varchar(45) DEFAULT NULL,
  `noofseats` int(11) DEFAULT NULL,
  `jobCategory` varchar(45) DEFAULT NULL,
  `qualification` varchar(45) DEFAULT NULL,
  `empid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empid_idx` (`empid`),
  CONSTRAINT `empid` FOREIGN KEY (`empid`) REFERENCES `Employer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;


insert into userdatabase.login (name,password) values('test','test');
insert into userdatabase.login(name,password)values('ujju','123');
insert into userdatabase.login(name,password)values('def','123');

insert into userdatabase.employer values(23,'sas','san mateo','sas@ymail.com','123','1231231231');
insert into userdatatbase.employer values(24,'twitter','san carlos','twi@gmail.com','124','1232312311');
