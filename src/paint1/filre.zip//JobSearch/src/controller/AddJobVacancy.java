package controller;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Vacancy;
import dao.VacancyDao;
public class AddJobVacancy extends HttpServlet{
	private static final long serialVersionUID = 1L;
    private static String JobCreate = RegisterServlet.JSP_PATH+"/jobCreate.jsp";
    
    private VacancyDao  dao = new VacancyDao();;

    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context;
		RequestDispatcher dispatch;
		
		context = getServletContext();
		dispatch = context.getRequestDispatcher("/WEB-INF/JSPs/addVacancy.jsp");
		dispatch.forward(request, response);
	}


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Vacancy vacancy = new Vacancy();
 		response.setContentType("text/html");
 		//System.out.println(request.getAttribute("empid1"));
		vacancy.setLocation(request.getParameter("location"));
		vacancy.setSkills_required(request.getParameter("skills_required"));
	    vacancy.setNoofseats(Integer.parseInt(request.getParameter("noofseats")));
	    vacancy.setJobCategory(request.getParameter("jobCategory"));
	    vacancy.setQualification(request.getParameter("qualification"));
	    vacancy.setEmpid(Integer.parseInt(request.getParameter("empid")));
	       
	    
	    try{
        	dao.addVacancy(vacancy);
        }catch(Exception e){
        	System.out.println(e);
        }
        
        RequestDispatcher view = request.getRequestDispatcher(JobCreate);
        request.setAttribute("vacancy", vacancy);
        view.forward(request, response);
    }

}
