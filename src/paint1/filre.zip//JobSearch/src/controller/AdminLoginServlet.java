package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Admin;
import dao.AdminDao;


public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String UserLogin =RegisterServlet.JSP_PATH+ "/loggedAdmin.jsp";
    private static String UserLoginError = RegisterServlet.JSP_PATH+"/loginerror.jsp";
    
       
	private AdminDao dao = new AdminDao();
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Admin admin = new Admin();
		response.setContentType("text/html");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		 try{
			 admin = dao.getAdminByName(email);
	        	if(!admin.hasPasswd(password)){

	        		request.setAttribute("error", "Either username or password is invalid.");
	        		 String nextPage =RegisterServlet.JSP_PATH+"adminlogin.jsp";
	        		 RequestDispatcher view = request.getRequestDispatcher(nextPage);
		      	        view.forward(request, response);
		      	    
	        	}
	        	else{

		       		 RequestDispatcher view = request.getRequestDispatcher(UserLogin);
		       	        request.setAttribute("users", admin);
		       	        view.forward(request, response);
		       		
	      	}
	        }catch(Exception e){

        		request.setAttribute("error", "Either username or password is invalid.");
        		 String nextPage =RegisterServlet.JSP_PATH+"adminlogin.jsp";
        		 RequestDispatcher view = request.getRequestDispatcher(nextPage);
	      	        view.forward(request, response);

	        }

		
        
	}


}
