package controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Employer;
import model.Vacancy;
import dao.EmployerDao;
import dao.VacancyDao;


public class DisplayJobByEmployer extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private static String LIST_JOB = RegisterServlet.JSP_PATH+"/displayJob.jsp";

	 private VacancyDao dao=new VacancyDao();; 
	 private EmployerDao empDao= new EmployerDao();
    
  
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Vacancy vacancy=new Vacancy();
    	Employer employer=new Employer();
    	String companyName= request.getParameter("companyName");
    	employer.setName(companyName);
    	RequestDispatcher view = request.getRequestDispatcher(LIST_JOB);
    	request.setAttribute("employer", dao.getVacancyCreatedByEmployer(companyName));
        view.forward(request, response);
    	
    	
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Vacancy vacancy = new Vacancy();
    	Employer employer=new Employer();
    	String companyName= request.getParameter("companyName");
         employer.setName(request.getParameter("companyName"));
         request.setAttribute("employer", dao.getVacancyCreatedByEmployer(companyName));
         RequestDispatcher view = request.getRequestDispatcher(RegisterServlet.JSP_PATH+"listJobbyEmployer.jsp");
         view.forward(request, response);

    }
    	   
    
    
    
  
   
}
