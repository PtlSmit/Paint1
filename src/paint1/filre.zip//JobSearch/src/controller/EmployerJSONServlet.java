package controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.json.*;
import javax.json.stream.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Employer;
import dao.EmployerDao;
import util.DbUtil;

public class EmployerJSONServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private EmployerDao dao= new EmployerDao();
       
    
    
    private void employerToJson(Employer employer, JsonGenerator jsonGenerator){
    	jsonGenerator.writeStartObject();
    	jsonGenerator.write("id", employer.getId());
    	jsonGenerator.write("companyName", employer.getCompanyName());
    	jsonGenerator.write("address", employer.getLocation());
    	jsonGenerator.write("email", employer.getEmail());
    	jsonGenerator.write("password", employer.getPassword());
    	jsonGenerator.write("contactNo", employer.getContactNo());
    	jsonGenerator.writeEnd();
    	
    }
    private void employerListToJson(ArrayList<Employer> employers, JsonGenerator jsonGenerator){
   // 	   private void employerListToJson(Employer employers, JsonGenerator jsonGenerator){
    		   
    	int i;
    	Employer employer;
    	jsonGenerator.writeStartObject(); /* Start of EmployerList object */
    	jsonGenerator.writeStartArray("EmployerList");
    	for(i=0;i<employers.size();i++){
    		Employer emp=employers.get(i);
    	
    		employerToJson(emp,jsonGenerator);
    	}
    		jsonGenerator.writeEnd(); /* End of EmployerList Array */
    		
    		jsonGenerator.writeEnd(); 
    	
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Employer> employers= dao.getEmployerList();//get list of employers
		for(Employer emp : employers){
			System.out.println("List" + emp);
		}
		JsonGeneratorFactory parserFactory =
		Json.createGeneratorFactory(null);
		JsonGenerator jsonGenerator;
		response.setContentType("application/json");
		
		PrintWriter out = response.getWriter();
		jsonGenerator = parserFactory.createGenerator(out);
		employerListToJson(employers, jsonGenerator);
		
		jsonGenerator.close();
		
	
	}

	


}
