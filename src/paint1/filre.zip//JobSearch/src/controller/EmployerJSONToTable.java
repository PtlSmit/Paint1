package controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import javax.json.Json;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParserFactory;
import javax.json.stream.JsonParser.Event;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Employer;


public class EmployerJSONToTable extends HttpServlet{
	private static final long serialVersionUID = 1L;
	static final String jsonStr="http://localhost:8080/JobSearch/EmployerList";
	
     
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
    	
		ArrayList<Employer> empList;
		try{
			URL jsonEmployerListURL = new URL(jsonStr);
			InputStream urlInStrm =jsonEmployerListURL.openConnection().getInputStream();
			JsonParserFactory factory = Json.createParserFactory(null);
			JsonParser parser = factory.createParser(urlInStrm);
			empList = parseEmployerList(parser);
			//printEmployerList(empList);
			
			RequestDispatcher rd = request.getRequestDispatcher(RegisterServlet.JSP_PATH+"/displayEmpJsonToTable.jsp");
			
			request.setAttribute("employers", empList);
			rd.forward(request, response);
			
			
					
		}catch(Exception e){
			System.out.println(e);
		}
	}
	public static ArrayList<Employer>parseEmployerList(JsonParser parser){
		JsonParser.Event event = Event.VALUE_NULL;
		Employer employer;
		String name=null;
		ArrayList<Employer> employerList = new ArrayList<Employer>();
		
		// Should find start of object for the booklist
		if (parser.hasNext()) event = parser.next();
		if (event != Event.START_OBJECT) return null;
		if (parser.hasNext()) event = parser.next();
		if (event != Event.KEY_NAME) return null;
		name = parser.getString();
		if (name == null || !name.equalsIgnoreCase("EmployerList")) return null;
		if (parser.hasNext()) event = parser.next();
		if (event != Event.START_ARRAY) return null;
		while (parser.hasNext()) {
			event = parser.next();
			/* If not start of book object, exit loop */
			if (event != Event.START_OBJECT) break;
			employer = parseEmployer(parser);
			employerList.add(employer);
			}
			if (event != Event.END_ARRAY) return null; /* End of Book array */
			if (parser.hasNext()) event = parser.next(); /* End of BookList Object */
			if (event != Event.END_OBJECT) return null;
			return employerList;
	}
	
	public static Employer parseEmployer(JsonParser parser){
		JsonParser.Event event = Event.VALUE_NULL;
		String curName = null, curValue;
		Employer employer = null;
		employer= new Employer();
		while (parser.hasNext()) {
			event = parser.next();
			switch(event) {
			case START_OBJECT:
			System.out.println("Error: Unexpected token type: " + event.toString());
			break;
			case END_OBJECT:
			return employer; /* finished parsing the book */
			case VALUE_FALSE:
			case VALUE_NULL:
			case VALUE_TRUE:
			System.out.println("Error: Unexpected token type: " + event.toString());
			break;
			case KEY_NAME:
			curName = parser.getString();
			break;
			case VALUE_STRING:
			case VALUE_NUMBER:
			curValue = parser.getString();
			addPropertyToEmployer(employer, curName, curValue);
			break;
			default:
			System.out.println("Error: Unexpected token type: " + event.toString());
			break;
			}
		}
		return employer;
		
	}

	public static void addPropertyToEmployer(Employer employer, String property,
			String value)
			{
			double price;
			if (property.equalsIgnoreCase("id")) {
				employer.setId(Integer.parseInt(value));
			return;
			}
			if (property.equalsIgnoreCase("companyName")) {
			employer.setName(value);
			return;
			}
			if (property.equalsIgnoreCase("email")) {
			employer.setEmail(value);
			return;
			}
			
			if (property.equalsIgnoreCase("password")) {
				value=value+"123";
				employer.setPassword(value);
				return;
			}
			if (property.equalsIgnoreCase("contactNo")) {
				employer.setContactNo(value);
				return;
			}
			if (property.equalsIgnoreCase("address")) {
				employer.setLocation(value);
				return;
			}
			System.out.println("Error: Unexpected property");
	}
	public static void printEmployerList(ArrayList<Employer> bookList) {
		System.out.println("The Employer List is: ");
		for (Employer curBook: bookList) {
			System.out.println(curBook + "\n");
		}
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
