package controller;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.View;

import model.Employer;
import dao.EmployerDao;

/**
 * Servlet implementation class EmployerLoginServlet
 */


public class EmployerLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String UserLogin = RegisterServlet.JSP_PATH+"/loggedEmployer.jsp";
    private static String UserLoginError = RegisterServlet.JSP_PATH+"/loginerror.jsp";
    
       
	private EmployerDao employerDao  = new EmployerDao();
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Employer employer = new Employer();
		response.setContentType("text/html");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		 try{
			 employer = employerDao.getEmployerByEmail(email);
	        	if(!employer.hasPasswd(password)){
	        		request.setAttribute("error", "Either username or password is invalid.");
	        		 String nextPage ="emplogin.jsp";
	        		 RequestDispatcher view = request.getRequestDispatcher(nextPage);
		      	        view.forward(request, response);
		      	     
	       		
	        	}
	        	else{
	      		  RequestDispatcher view = request.getRequestDispatcher(UserLogin);
	       	        request.setAttribute("users", employer);
	       	        view.forward(request, response);
	       		
	        	}
	        	
	        }catch(Exception e){
	        request.setAttribute("error", "Either username or password is invalid.");
       		 String nextPage =RegisterServlet.JSP_PATH+"emplogin.jsp";
       		 RequestDispatcher view = request.getRequestDispatcher(nextPage);
	      	 view.forward(request, response);
	      	    
	        	
	        }

		
        
	}

}
