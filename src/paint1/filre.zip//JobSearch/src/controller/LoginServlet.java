package controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.User;
import dao.UserDao;
public class LoginServlet extends HttpServlet{
    private static final long serialVersionUID = 1L;
    
    private UserDao dao = new UserDao();

    

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");
    	try{
    	String nextPage="";
    	User user = new User();
        user.setEmail(request.getParameter("email"));
		user.setPassword(request.getParameter("password"));
		synchronized(this){
			
		user=dao.login(user);
		if(!(user.isValid()) || user == null){
			request.setAttribute("error", "Either username or password is invalid.");
		    nextPage =RegisterServlet.JSP_PATH+"login.jsp";
			
		}
		else {
			
			HttpSession session = request.getSession(true); 
			nextPage=RegisterServlet.JSP_PATH+"loggedUser.jsp";
			
		}
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(nextPage);
		request.setAttribute("users", user);
		rd.forward(request, response);
		}catch(Throwable ex){
    	System.out.println(ex);
		}
    	
    }
}
