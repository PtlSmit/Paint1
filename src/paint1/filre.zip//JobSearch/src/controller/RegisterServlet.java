package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import dao.UserDao;


import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

public class RegisterServlet extends HttpServlet {

	private UserDao dao=new UserDao();
	public static final String JSP_PATH="/WEB-INF/JSPs/";

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = new User();
    	response.setContentType("text/html");
		
		
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
	    user.setFirstName(firstName);
        user.setLastName(lastName);
        try {
            Date dob = new SimpleDateFormat("MM/dd/yyyy").parse(request.getParameter("dob"));
            user.setDob(dob);
        } catch (ParseException | java.text.ParseException e) {
            e.printStackTrace();
        }
        user.setEmail(request.getParameter("email"));
        user.setAddress(request.getParameter("address"));
        user.setSkill(request.getParameter("skill"));
        user.setQualification(request.getParameter("qualification"));
        user.setContactNo(request.getParameter("contactNo"));
        user.setPassword(request.getParameter("password"));
        try{
        	dao.addUser(user);
        	User user1=dao.getUserById(request.getParameter("email"));
        	user.setUserid(user1.getUserid());
        }catch(Exception e){
        	System.out.println(e);
        }
        
        RequestDispatcher view = request.getRequestDispatcher(JSP_PATH+"login.jsp");
        request.setAttribute("users", user);
        view.forward(request, response);
    }

}
