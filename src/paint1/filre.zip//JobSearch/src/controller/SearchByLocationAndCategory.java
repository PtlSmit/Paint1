package controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import model.Vacancy;
import dao.VacancyDao;

public class SearchByLocationAndCategory extends HttpServlet{
private static String LIST_JOB = RegisterServlet.JSP_PATH+"/search.jsp";

    
    private VacancyDao dao=new VacancyDao();
    

   


    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Vacancy vacancy = new Vacancy(); 
    	    
    	String jobCategory=request.getParameter("jobCategory");
		String location=request.getParameter("location");
	    vacancy.setJobCategory(jobCategory);
	    vacancy.setLocation(location);
	   
    	RequestDispatcher view = request.getRequestDispatcher(LIST_JOB);
	    
        request.setAttribute("vacancy", dao.getAllVacancy(jobCategory,location));
        view.forward(request, response);
        
    
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Vacancy vacancy = new Vacancy();
    	String jobCategory=request.getParameter("jobCategory");
		String location=request.getParameter("location");
         vacancy.setLocation(request.getParameter("location"));
         
         request.setAttribute("vacancy", dao.getAllVacancy(jobCategory, location));
         RequestDispatcher view = request.getRequestDispatcher(RegisterServlet.JSP_PATH+"listJob.jsp");
         view.forward(request, response);

    }
    	   

}
