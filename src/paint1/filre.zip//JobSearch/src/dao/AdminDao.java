package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Admin;
import util.DbUtil;


public class AdminDao {
	private Connection connection;
	public AdminDao(){
		connection= DbUtil.getConnection();
	}
	public Admin getAdminByName(String name){
		Admin admin = new Admin();
		try {
            PreparedStatement preparedStatement = connection.
                    prepareStatement("select * from login where name=?");
            preparedStatement.setString(1, name);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
            	admin.setId(rs.getInt("id"));
                admin.setName(rs.getString("name"));
                admin.setPassword(rs.getString("password"));
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

		return admin;
		
	}

}
