package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import util.DbUtil;
import model.Employer;
import model.User;

public class EmployerDao {
	private Connection connection;
	public EmployerDao(){
		connection = DbUtil.getConnection();	   
	}

	public void addEmployer(Employer employer){
		 try {
	            PreparedStatement preparedStatement = connection
	                    .prepareStatement("insert into Employer(name,address,email,password,contactNo) values (?, ?, ?, ? ,?)");
	            // Parameters start with 1
	            preparedStatement.setString(1, employer.getCompanyName());
	            preparedStatement.setString(2, employer.getEmail());
	            preparedStatement.setString(3, employer.getPassword());
	            preparedStatement.setString(4, employer.getContactNo());
	            preparedStatement.setString(5, employer.getLocation());
	            preparedStatement.executeUpdate();

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }		
	}
	public Employer getEmployerByEmail(String email) {
		Employer employer = new Employer();
		try {
            PreparedStatement preparedStatement = connection.
                    prepareStatement("select * from Employer where email=?");
            preparedStatement.setString(1, email);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
            	employer.setId(rs.getInt("id"));
            	employer.setName(rs.getString("companyName"));
                employer.setEmail(rs.getString("email"));
                employer.setLocation(rs.getString("address"));
                employer.setContactNo(rs.getString("contactNo"));
                employer.setPassword(rs.getString("password"));
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return employer;
    }

	public ArrayList<Employer> getEmployerList() {
		ArrayList<Employer> employers = new ArrayList<Employer>();
		try {
            Statement statement = connection.createStatement();
           
            ResultSet rs = statement.executeQuery( "select * from Employer");
            while(rs.next()) {
            	Employer employer = new Employer();
            	employer.setId(rs.getInt("id"));
            	employer.setName(rs.getString("companyName"));
                employer.setEmail(rs.getString("email"));
                employer.setLocation(rs.getString("address"));
                employer.setContactNo(rs.getString("contactNo"));
                employer.setPassword(rs.getString("password"));
                employers.add(employer);
              //  System.out.println("list : " + employer);

                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
		
        return employers;
    }
	
	public String createStaticJSON(ArrayList<Employer> employers){
    	Gson gson = new  GsonBuilder().setPrettyPrinting().create();
    	String json = gson.toJson(employers);
        return json;
        
    }
	
	
	public int getEmployerId(String companyName){
		int id=0;
		try{
			String searchQuery="select id from Employer where email='" + companyName + "'";
			PreparedStatement preparedStatement = connection.
                    prepareStatement(searchQuery);
            ResultSet rs = preparedStatement.executeQuery();
            if(rs.next()){
            	id= rs.getInt("id");
            	//return id;
            }
			
			
		}catch(Exception ex){
			System.out.println(ex);
		}
		return id;
	}


}
