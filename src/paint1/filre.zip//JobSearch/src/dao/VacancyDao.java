package dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import java.sql.PreparedStatement;

import util.DbUtil;
import model.Vacancy;

public class VacancyDao {
	private Connection connection;

    public VacancyDao() {
        connection = DbUtil.getConnection();
    }

    public List<Vacancy> getAllVacancy(String jobCategory,String location) {
        List<Vacancy> vacancies = new ArrayList<Vacancy>();
        try {
        	PreparedStatement preparedStatement = connection.prepareStatement("select * from vacancy where jobCategory=? and location=?");
        	preparedStatement.setString(1, jobCategory);
        	preparedStatement.setString(2,location);
            ResultSet rs = preparedStatement.executeQuery();
  
            while (rs.next()) {
                Vacancy vacancy = new Vacancy();
                vacancy.setId(rs.getInt("id"));
                vacancy.setLocation(rs.getString("location"));
                vacancy.setSkills_required(rs.getString("skills_required"));
                vacancy.setNoofseats(rs.getInt("noofseats"));
                vacancy.setJobCategory(rs.getString("jobCategory"));
                vacancy.setQualification(rs.getString("qualification"));
               
                vacancies.add(vacancy);
                System.out.println(vacancy);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vacancies;
    }


    public Vacancy getVacancy(String jobCategory,String location) {
        Vacancy vacancies = new Vacancy();
        try {
        	PreparedStatement preparedStatement = connection.prepareStatement("select * from vacancy where jobCategory=? and location=?");
        	preparedStatement.setString(1, jobCategory);
        	preparedStatement.setString(2,location);
            ResultSet rs = preparedStatement.executeQuery();
  
            while (rs.next()) {
                Vacancy vacancy = new Vacancy();
                vacancy.setId(rs.getInt("id"));
                vacancy.setLocation(rs.getString("location"));
                vacancy.setSkills_required(rs.getString("skills_required"));
                vacancy.setNoofseats(rs.getInt("noofseats"));
                vacancy.setJobCategory(rs.getString("jobCategory"));
                vacancy.setQualification(rs.getString("qualification"));
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vacancies;
    }

    public void addVacancy(Vacancy vacancy){
    	
    	try {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into Vacancy(location,skills_required,noofseats,jobCategory,qualification,empid) values (?, ?, ?, ? ,?,?)");
            preparedStatement.setString(1, vacancy.getLocation());
            preparedStatement.setString(2, vacancy.getSkills_required());
            preparedStatement.setInt(3, vacancy.getNoofseats());
            preparedStatement.setString(4, vacancy.getJobCategory());
            preparedStatement.setString(5, vacancy.getQualification());               
            preparedStatement.setInt(6, vacancy.getEmpid());                   
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    
    
    public ArrayList<Vacancy> getVacancyCreatedByEmployer(String companyName) {
        ArrayList<Vacancy> vacancies = new ArrayList<Vacancy>();
        try {
        	String searchQuery="select a.id,a.location,a.skills_required,a.jobCategory from Vacancy a, Employer b where a.empid=b.id and b.companyName like '"+companyName+"'";
        	PreparedStatement preparedStatement = connection.prepareStatement(searchQuery);
            ResultSet rs = preparedStatement.executeQuery();
  
            while (rs.next()) {
                Vacancy vacancy = new Vacancy();
                vacancy.setId(rs.getInt("id"));
                vacancy.setLocation(rs.getString("location"));
                vacancy.setSkills_required(rs.getString("skills_required"));
                vacancy.setJobCategory(rs.getString("jobCategory"));
                vacancies.add(vacancy);
                System.out.println(vacancy);
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vacancies;
    }
    
    //Transaction occurs here...
    public void deleteVacancy(int id) throws SQLException{
    	try{
    		connection.setAutoCommit(false);
    		String deletestatement=("delete from vacancy1 where empid=?");
    		PreparedStatement preparedStatement=connection.prepareStatement(deletestatement);
    		preparedStatement.setInt(1, id);
    		preparedStatement.executeUpdate();
    		connection.commit();
    	}catch(SQLException e){
    		e.printStackTrace();
    		connection.rollback();
    		
    		
    	}
    	
    }
    

}
