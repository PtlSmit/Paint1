package model;

public class Employer {
	private int id;
	private String companyName;
	private String email;
	private String password;
	private String contactNo;
	private String location;
	
	public Employer(){
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	
	public String getCompanyName() {
		return companyName;
	}

	public void setName(String name) {
		this.companyName = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public boolean hasPasswd(String passwd){
		if(password.equals(passwd)) return true;
		else return false;
	}
	@Override
	public String toString() {
		return "Employer [id=" + id + ", companyName=" + companyName + ", email=" + email
				+ ", password=" + password + ", contactNo=" + contactNo
				+ ", location=" + location + "]";
	}

	

}
