package model;

public class Vacancy {
	private int id;
	private String location;
	private String skills_required;
	private int noofseats;
	private String jobCategory;
	private String qualification;
	private int empid;
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSkills_required() {
		return skills_required;
	}
	public void setSkills_required(String skills_required) {
		this.skills_required = skills_required;
	}
	public int getNoofseats() {
		return noofseats;
	}
	public void setNoofseats(int noofseats) {
		this.noofseats = noofseats;
	}
	public String getJobCategory() {
		return jobCategory;
	}
	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	@Override
	public String toString() {
		return "Vacancy [id=" + id + ", location=" + location
				+ ", skills_required=" + skills_required + ", noofseats="
				+ noofseats + ", jobCategory=" + jobCategory
				+ ", qualification=" + qualification + "]";
	}
	
	

}
